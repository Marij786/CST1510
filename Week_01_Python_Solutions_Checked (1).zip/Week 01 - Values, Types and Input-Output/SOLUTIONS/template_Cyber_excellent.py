source_ip = input("Source IP: ")
failed_logins = float(input("Failed logins: "))
total_attempts = float(input("Total attempts: "))

successful_logins = total_attempts - failed_logins
failure_percent = (failed_logins / total_attempts) * 100

# Successful logins help show the complementary outcome of the attempts.
print()
print("=" * 34)
print(f"  RECORD CHECK  -  {source_ip}")
print("=" * 34)
print(f"  Failed      : {failed_logins:>10.2f}")
print(f"  Attempts    : {total_attempts:>10.2f}")
print(f"  Successful  : {successful_logins:>10.2f}")
print(f"  Percent     : {failure_percent:>9.1f} %")
print(f"  Difference  : {(failed_logins - total_attempts):>+10.2f}")
print("=" * 34)
