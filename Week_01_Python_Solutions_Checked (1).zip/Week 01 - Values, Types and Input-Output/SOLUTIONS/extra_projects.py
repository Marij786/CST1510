# Band Name Generator
print("Welcome to the Band Name Generator!")
city = input("Which city did you grow up in? ")
pet = input("What is your pet's name? ")
print(f"Your band name could be {city} {pet}")

# Tip Calculator
bill = float(input("Total bill: "))
people = int(input("Number of people: "))
tip_percent = float(input("Tip percentage: "))
each_person = (bill / people) * (1 + tip_percent / 100)
print(f"Each person should pay: ${each_person:.2f}")
