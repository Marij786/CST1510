hostname = input("Hostname: ")
used_gb = float(input("GB used: "))
total_gb = float(input("GB total: "))

free_gb = total_gb - used_gb
percent_used = (used_gb / total_gb) * 100

# Free space is useful for IT capacity monitoring.
print()
print("=" * 34)
print(f"  RECORD CHECK  -  {hostname}")
print("=" * 34)
print(f"  Used        : {used_gb:>10.2f} GB")
print(f"  Total       : {total_gb:>10.2f} GB")
print(f"  Free        : {free_gb:>10.2f} GB")
print(f"  Percent     : {percent_used:>9.1f} %")
print(f"  Difference  : {(used_gb - total_gb):>+10.2f} GB")
print("=" * 34)
