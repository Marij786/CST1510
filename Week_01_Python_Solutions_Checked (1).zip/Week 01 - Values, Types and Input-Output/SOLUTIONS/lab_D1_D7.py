# D1
name = "Your Name"
print("=" * 30)
print(f"CST1510 - {name}")
print("=" * 30)

# D2 + D3
record_id = "R-017"
value = 41.2
limit = 50
print(record_id)
print(value)
print(limit)
difference = value - limit
percent = (value / limit) * 100
print("Difference:", difference)
print("Percent:", percent)

# D4 + D5
record_id = input("Record ID: ")
value = float(input("Value: "))
limit = float(input("Limit: "))
difference = value - limit
percent = (value / limit) * 100
print(f"Record ID : {record_id}")
print(f"Value     : {value:>10.2f}")
print(f"Limit     : {limit:>10.2f}")
print(f"Difference: {difference:>+10.2f}")
print(f"Percent   : {percent:>10.2f} %")

# D6
total_seconds = 4831
hours = total_seconds // 3600
remaining = total_seconds % 3600
minutes = remaining // 60
seconds = remaining % 60
print(f"{total_seconds} seconds = {hours} hours, {minutes} minutes, {seconds} seconds")

# D7
part = float(input("Part: "))
total = float(input("Total: "))
label = input("Label: ")
percentage = (part / total) * 100
print(f"{label:<15}: {part:g} of {total:g} = {percentage:.1f} %")
