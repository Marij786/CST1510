value = float(input("Value: "))
print(value + 1)
