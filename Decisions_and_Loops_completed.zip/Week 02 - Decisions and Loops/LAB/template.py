"""Week 2 Record Check - completed Excellent version."""
over_limit_count=0
records_checked=0

while True:
    label=input("Record label (or 'quit'): ")
    if label.lower()=="quit":
        break
    value=float(input("Value: "))
    limit=float(input("Limit: "))
    difference=value-limit
    percent=(value/limit)*100
    if percent>=100:
        status="OVER LIMIT"
        over_limit_count+=1
    elif percent>=90:
        status="WARNING"
    else:
        status="OK"
    records_checked+=1
    print()
    print("="*34)
    print(f"  RECORD CHECK - {label}")
    print("="*34)
    print(f"  Value:      {value:>10.2f}")
    print(f"  Limit:      {limit:>10.2f}")
    print(f"  Difference: {difference:>10.2f}")
    print(f"  Percent:    {percent:>9.2f}%")
    print(f"  Status:     {status}")
    print("="*34)
print(f"Records checked: {records_checked}")
print(f"Over-limit records: {over_limit_count}")
